applican.notification.alert("", function(){ alert(1);}, "title", "buttonname");
