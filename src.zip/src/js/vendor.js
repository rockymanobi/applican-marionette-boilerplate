// vendor
var $ = require('jquery');
var _ = require('underscore');
var moment = require('moment');
var Backbone   = require('backbone');
Backbone.$ = $;
require('backbone.marionette');
