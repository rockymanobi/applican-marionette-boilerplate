var Backbone = require('backbone');
module.exports = (function () {
  var MainNavModel = Backbone.Model.extend({
  });

  return MainNavModel;
})();
